public class pegawaiTetap {
    public double pegawaiT(int lem) {
        int gp = 10_000_000;
        int lm = lem * 75_000;
        double t = gp * 0.24;
        return gp + lm + t;
    }
}

//    public int jmlhMaksimal(int jmlh){
//
//    }
//}
